#!/usr/bin/env bash

# current directory must be the backend folder
sudo apt-get install sqlite3
sqlite3 ./db.sqlite3 < ./database.sql

