BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS `user_user_user_permissions` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`user_id`	integer NOT NULL,
	`permission_id`	integer NOT NULL,
	FOREIGN KEY(`permission_id`) REFERENCES `auth_permission`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`user_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE IF NOT EXISTS `user_user_groups` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`user_id`	integer NOT NULL,
	`group_id`	integer NOT NULL,
	FOREIGN KEY(`group_id`) REFERENCES `auth_group`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`user_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE IF NOT EXISTS `user_user` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`password`	varchar ( 128 ) NOT NULL,
	`last_login`	datetime,
	`is_superuser`	bool NOT NULL,
	`email`	varchar ( 255 ) NOT NULL UNIQUE,
	`name`	varchar ( 255 ) NOT NULL,
	`username`	varchar ( 255 ) NOT NULL UNIQUE,
	`is_active`	bool NOT NULL,
	`is_staff`	bool NOT NULL,
	`role`	integer NOT NULL
);
INSERT INTO `user_user` VALUES (1,'pbkdf2_sha256$120000$DStmJgh40iBE$o+64ulgJl3VFLPgNoZNh6RmqcxCMJVVGeTuTT+jmQjQ=',NULL,0,'eminvergili@hotmail.com','Emin Vergili','meverg',1,0,0);
INSERT INTO `user_user` VALUES (2,'pbkdf2_sha256$120000$n5KFqG2skoYd$hFaWgrnhziyPvgUHoB2MZAHe/fgjuTUrD8sSs027tZg=',NULL,0,'kaan.ozgen12@gmail.com','kaan.ozgen','kaan.ozgen',1,0,1);
INSERT INTO `user_user` VALUES (3,'pbkdf2_sha256$120000$OwENbmp9EuTH$fzYjBbgawQu9d91bRX36cMdYyBATXTKJNqJ2+dROtm8=',NULL,0,'kemal@gmail.com','Kemal Erim','Kerim',1,0,0);
INSERT INTO `user_user` VALUES (4,'pbkdf2_sha256$120000$anVZOCa4nINv$hbG1xOctu1eRe/b9zLrZZd00eKppIQlf23L6/Eg2XFg=',NULL,0,'ahmetdemir@gmail.com','Ahmet Demir','ademir',1,0,0);
INSERT INTO `user_user` VALUES (5,'pbkdf2_sha256$120000$zBlPDtL9iMey$/xm20OM6h6ZlUJShF+h6HluREFEYgLBVqFKyWw3H4Y8=',NULL,0,'tuna@gmail.com','Tuna Güngör','TunaG',1,0,1);
INSERT INTO `user_user` VALUES (6,'pbkdf2_sha256$120000$rCtgSKcfxbxj$dl+DWVvD0XBHVzjn7amowVXK6nEhl0pXW5GznT/tgf0=',NULL,0,'cnbrkyldrm@hotmail.com','Canberk Yıldırım','canberky',1,0,0);
INSERT INTO `user_user` VALUES (7,'pbkdf2_sha256$120000$fPWzsp7nmXQI$OCyikugLt8LJp3+/iBndps2WRcDKxtQQK0XkVxTX/e0=',NULL,0,'anonymous@gmail.com','Anonymous','Anonymous',1,0,0);
INSERT INTO `user_user` VALUES (8,'pbkdf2_sha256$120000$W0WznqHCQM9f$e7Zz2cvwZnGIAL13d4PR/sDpCR2Feaiya3ovTEEhUuM=',NULL,0,'susan_kelso@hb.com','Susan Kelso','susan_susi',1,0,1);
INSERT INTO `user_user` VALUES (9,'pbkdf2_sha256$120000$u7u1ZfjzMEoC$RsYjPvW7AAoRqYwQClWF98BLybVTY9LkL4eltjExY6I=',NULL,0,'free_4ever@hb.com','Will Independent','willindep',1,0,0);
INSERT INTO `user_user` VALUES (10,'pbkdf2_sha256$120000$qpIl90WW0YCg$Y/V691XAOKskCZ6dakgp63ziEzKTI2/iWyLzzzM7uXA=',NULL,0,'dummy@hb.com','dummy lol','dummy1',1,0,0);
INSERT INTO `user_user` VALUES (11,'pbkdf2_sha256$120000$6BNFelWF0Hgf$EG3DJGfKpRCtgEIUMy1BnHAEhsC4KGe58K9Eb7lRCpk=',NULL,0,'huseyin@gmail.com','huse.1','123456',1,0,0);
INSERT INTO `user_user` VALUES (12,'pbkdf2_sha256$120000$CTJxL6DNOKsh$4EtPkfWi8UyUxjBeOJIo4iN9shP6cQUJg1rJtW2JT9k=',NULL,0,'mehmet.mehmet12@gmail.com','mehmet1e','mehmet1e',1,0,0);
INSERT INTO `user_user` VALUES (13,'pbkdf2_sha256$120000$m7G7mdNSlY8Z$RJYqRhlCvt8fj+MSooVPXm4bG9RY4KGCyyYq6tbix7g=',NULL,0,'keremozgen@gmail.com','krmzgn','krmzgn',1,0,0);
INSERT INTO `user_user` VALUES (14,'pbkdf2_sha256$120000$YNX2cl129w0h$CjoRwoEdOtedGtWESVKH8QXjrqREPQhTxqoGAT5LyqE=',NULL,0,'afcelimli@gmail.com','Ahmet Faruk Çelimli','afcelimli',1,0,0);
INSERT INTO `user_user` VALUES (15,'a',NULL,0,'a@a.com','Emilie Kingdon','Emilie',1,0,1);
INSERT INTO `user_user` VALUES (16,'pbkdf2_sha256$120000$xFtKFtAtZJjA$rXkGAmirD6EaxyBacd7sUEbRdIeDE2IpJLl9cH5tydM=',NULL,0,'afcelimli@hotmail.com','Ahmet Faruk Çelimli','afcelimli2',1,0,0);
CREATE TABLE IF NOT EXISTS `user_freelancerprofile_tags` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`freelancerprofile_id`	integer NOT NULL,
	`tag_id`	integer NOT NULL,
	FOREIGN KEY(`freelancerprofile_id`) REFERENCES `user_freelancerprofile`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`tag_id`) REFERENCES `project_tag`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `user_freelancerprofile_tags` VALUES (10,3,64);
INSERT INTO `user_freelancerprofile_tags` VALUES (11,1,15);
INSERT INTO `user_freelancerprofile_tags` VALUES (12,4,52);
INSERT INTO `user_freelancerprofile_tags` VALUES (13,6,51);
INSERT INTO `user_freelancerprofile_tags` VALUES (15,7,15);
INSERT INTO `user_freelancerprofile_tags` VALUES (16,9,15);
INSERT INTO `user_freelancerprofile_tags` VALUES (17,2,52);
INSERT INTO `user_freelancerprofile_tags` VALUES (18,2,53);
INSERT INTO `user_freelancerprofile_tags` VALUES (19,10,36);
INSERT INTO `user_freelancerprofile_tags` VALUES (20,2,3);
INSERT INTO `user_freelancerprofile_tags` VALUES (24,13,50);
INSERT INTO `user_freelancerprofile_tags` VALUES (25,14,14);
CREATE TABLE IF NOT EXISTS `user_freelancerprofile` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`avatar`	varchar ( 100 ),
	`body`	text NOT NULL,
	`created_at`	datetime NOT NULL,
	`rating`	real NOT NULL,
	`user_id`	integer NOT NULL UNIQUE,
	FOREIGN KEY(`user_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `user_freelancerprofile` VALUES (1,'images/yinyang_noisy.png','Beginner level computer engineer','2019-01-02 14:54:35.622916',0.0,1);
INSERT INTO `user_freelancerprofile` VALUES (2,'images/20171016_160858.jpg','Hello , an experienced programmer fluent in PHP and CSS','2019-01-02 15:04:34.720681',0.0,2);
INSERT INTO `user_freelancerprofile` VALUES (3,'images/Kemal_Gultekin.png','Hi, it''s Kemal. I am a senior sociology student. I worked as an intern in firms operating in advertisement. I think, I am good at designing and graphics.','2019-01-02 15:20:07.102348',0.0,3);
INSERT INTO `user_freelancerprofile` VALUES (4,'images/2BA9AA99-0B04-4B39-A256-1DC4D2B528B2.jpeg','I’m a graphic designer','2019-01-02 15:34:16.402113',0.0,4);
INSERT INTO `user_freelancerprofile` VALUES (5,'','','2019-01-02 15:37:07.456497',0.0,5);
INSERT INTO `user_freelancerprofile` VALUES (6,'images/canberk.jpg','I am the most complete cinematographer, in the world','2019-01-02 16:00:16.154125',0.0,6);
INSERT INTO `user_freelancerprofile` VALUES (7,'images/vfor.jpeg','Tellin'' ya bout myself','2019-01-02 16:16:38.595129',0.0,7);
INSERT INTO `user_freelancerprofile` VALUES (8,'','','2019-01-02 16:35:43.474843',0.0,8);
INSERT INTO `user_freelancerprofile` VALUES (9,'images/98.jpg','I am THE VERY BEST front end developer. 
___*** ONLY JavaScript ;) ***___','2019-01-02 16:42:58.826613',0.0,9);
INSERT INTO `user_freelancerprofile` VALUES (10,'images/dog.jpeg','asdfasdfs','2019-01-02 16:54:56.761322',0.0,10);
INSERT INTO `user_freelancerprofile` VALUES (11,'','','2019-01-02 17:04:14.510857',0.0,11);
INSERT INTO `user_freelancerprofile` VALUES (12,'','','2019-01-02 17:04:54.326387',0.0,12);
INSERT INTO `user_freelancerprofile` VALUES (13,'','Merhabaa','2019-01-02 17:05:14.390462',0.0,13);
INSERT INTO `user_freelancerprofile` VALUES (14,'images/headshot.png','I''m a senior computer engineering student at Boğaziçi University. You can check my github accounts from the following link.
https://github.com/afcelimli','2019-01-02 20:35:34.369496',0.0,14);
INSERT INTO `user_freelancerprofile` VALUES (15,'','','2019-01-03 13:41:30.786673',0.0,15);
INSERT INTO `user_freelancerprofile` VALUES (16,'','','2019-01-06 14:38:49.326916',0.0,16);
CREATE TABLE IF NOT EXISTS `user_clientprofile_tags` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`clientprofile_id`	integer NOT NULL,
	`tag_id`	integer NOT NULL,
	FOREIGN KEY(`tag_id`) REFERENCES `project_tag`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`clientprofile_id`) REFERENCES `user_clientprofile`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `user_clientprofile_tags` VALUES (1,1,50);
INSERT INTO `user_clientprofile_tags` VALUES (2,5,9);
INSERT INTO `user_clientprofile_tags` VALUES (3,8,17);
INSERT INTO `user_clientprofile_tags` VALUES (4,10,34);
INSERT INTO `user_clientprofile_tags` VALUES (5,15,57);
INSERT INTO `user_clientprofile_tags` VALUES (6,16,14);
CREATE TABLE IF NOT EXISTS `user_clientprofile` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`avatar`	varchar ( 100 ),
	`body`	text NOT NULL,
	`created_at`	datetime NOT NULL,
	`rating`	real NOT NULL,
	`user_id`	integer NOT NULL UNIQUE,
	FOREIGN KEY(`user_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `user_clientprofile` VALUES (1,'images/yinyang.png','I just want to have good service in return for my money...','2019-01-02 14:54:35.627024',0.0,1);
INSERT INTO `user_clientprofile` VALUES (2,'','','2019-01-02 15:04:34.724919',0.0,2);
INSERT INTO `user_clientprofile` VALUES (3,'','','2019-01-02 15:20:07.106187',0.0,3);
INSERT INTO `user_clientprofile` VALUES (4,'','','2019-01-02 15:34:16.406017',0.0,4);
INSERT INTO `user_clientprofile` VALUES (5,'images/fft99_mf3657141.Jpeg','Hi, I am a father of two sons. I want them to learn programming therefore need a young teacher for that. If you see my project and come to here you can contact me from my phone number: 0509 876 98 88','2019-01-02 15:37:07.460592',0.0,5);
INSERT INTO `user_clientprofile` VALUES (6,'','','2019-01-02 16:00:16.158193',0.0,6);
INSERT INTO `user_clientprofile` VALUES (7,'','','2019-01-02 16:16:38.599071',0.0,7);
INSERT INTO `user_clientprofile` VALUES (8,'images/lena200.png','A coffee shop owner I am
I want my website tomorrow by 10','2019-01-02 16:35:43.478727',0.0,8);
INSERT INTO `user_clientprofile` VALUES (9,'','','2019-01-02 16:42:58.830766',0.0,9);
INSERT INTO `user_clientprofile` VALUES (10,'images/dog_KrQvCA0.jpeg','asdfasdfasdf','2019-01-02 16:54:56.765749',0.0,10);
INSERT INTO `user_clientprofile` VALUES (11,'','','2019-01-02 17:04:14.514516',0.0,11);
INSERT INTO `user_clientprofile` VALUES (12,'','','2019-01-02 17:04:54.330282',0.0,12);
INSERT INTO `user_clientprofile` VALUES (13,'','','2019-01-02 17:05:14.394629',0.0,13);
INSERT INTO `user_clientprofile` VALUES (14,'','','2019-01-02 20:35:34.373423',0.0,14);
INSERT INTO `user_clientprofile` VALUES (15,'images/39.jpg','I am new in this website.','2019-01-03 13:41:30.791155',0.0,15);
INSERT INTO `user_clientprofile` VALUES (16,'images/Ekran_Resmi_2018-02-26_00.36.07.png','I''m a senior computer engineering student at Boun.','2019-01-06 14:38:49.331652',0.0,16);
CREATE TABLE IF NOT EXISTS `upload_uploadimage` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`url`	varchar ( 100 ) NOT NULL,
	`user_id`	integer NOT NULL,
	FOREIGN KEY(`user_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `upload_uploadimage` VALUES (1,'images/download.jpeg',7);
INSERT INTO `upload_uploadimage` VALUES (2,'images/old-photos-that-need-restorati.jpg',15);
CREATE TABLE IF NOT EXISTS `project_tag` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`title`	varchar ( 100 ) NOT NULL
);
INSERT INTO `project_tag` VALUES (1,'Website Design');
INSERT INTO `project_tag` VALUES (2,'HTML');
INSERT INTO `project_tag` VALUES (3,'PHP');
INSERT INTO `project_tag` VALUES (4,'CSS');
INSERT INTO `project_tag` VALUES (5,'Data Processing');
INSERT INTO `project_tag` VALUES (6,'MySQL');
INSERT INTO `project_tag` VALUES (7,'Artificial Intelligence');
INSERT INTO `project_tag` VALUES (8,'C Programming');
INSERT INTO `project_tag` VALUES (9,'Java');
INSERT INTO `project_tag` VALUES (10,'C# Programming');
INSERT INTO `project_tag` VALUES (11,'Web Scraping');
INSERT INTO `project_tag` VALUES (12,'Web Search');
INSERT INTO `project_tag` VALUES (13,'Web Security');
INSERT INTO `project_tag` VALUES (14,'Django');
INSERT INTO `project_tag` VALUES (15,'JavaScript');
INSERT INTO `project_tag` VALUES (16,'SQL');
INSERT INTO `project_tag` VALUES (17,'eCommerce');
INSERT INTO `project_tag` VALUES (18,'Game Development');
INSERT INTO `project_tag` VALUES (19,'Hadoop');
INSERT INTO `project_tag` VALUES (20,'Neural Networks');
INSERT INTO `project_tag` VALUES (21,'Backend Development');
INSERT INTO `project_tag` VALUES (22,'Microsoft');
INSERT INTO `project_tag` VALUES (23,'BigCommerce');
INSERT INTO `project_tag` VALUES (24,'Image Processing');
INSERT INTO `project_tag` VALUES (25,'Javascript');
INSERT INTO `project_tag` VALUES (26,'Android');
INSERT INTO `project_tag` VALUES (27,'iOS Development');
INSERT INTO `project_tag` VALUES (28,'Game Development');
INSERT INTO `project_tag` VALUES (29,'Microsoft');
INSERT INTO `project_tag` VALUES (30,'Apple Xcode');
INSERT INTO `project_tag` VALUES (31,'Translation');
INSERT INTO `project_tag` VALUES (32,'English');
INSERT INTO `project_tag` VALUES (33,'German');
INSERT INTO `project_tag` VALUES (34,'French');
INSERT INTO `project_tag` VALUES (35,'Spanish');
INSERT INTO `project_tag` VALUES (36,'Italian');
INSERT INTO `project_tag` VALUES (37,'Turkish');
INSERT INTO `project_tag` VALUES (38,'Chinese');
INSERT INTO `project_tag` VALUES (39,'Data Processing');
INSERT INTO `project_tag` VALUES (40,'Analytics');
INSERT INTO `project_tag` VALUES (41,'AutoCAD');
INSERT INTO `project_tag` VALUES (42,'Academic Writing');
INSERT INTO `project_tag` VALUES (43,'eBooks');
INSERT INTO `project_tag` VALUES (44,'Account Management');
INSERT INTO `project_tag` VALUES (45,'Accounting');
INSERT INTO `project_tag` VALUES (46,'Contracts');
INSERT INTO `project_tag` VALUES (47,'Payroll');
INSERT INTO `project_tag` VALUES (48,'Cover & Packaging');
INSERT INTO `project_tag` VALUES (49,'Leads');
INSERT INTO `project_tag` VALUES (50,'3D Animation');
INSERT INTO `project_tag` VALUES (51,'Cinematography');
INSERT INTO `project_tag` VALUES (52,'Graphic Design');
INSERT INTO `project_tag` VALUES (53,'Graphic Design, 3D Design');
INSERT INTO `project_tag` VALUES (54,'3D Animation');
INSERT INTO `project_tag` VALUES (55,'3D Rendering');
INSERT INTO `project_tag` VALUES (56,'Building Architecture');
INSERT INTO `project_tag` VALUES (57,'Digital Design');
INSERT INTO `project_tag` VALUES (58,'Visual Arts');
INSERT INTO `project_tag` VALUES (59,'Audio Production');
INSERT INTO `project_tag` VALUES (60,'T-Shirts');
INSERT INTO `project_tag` VALUES (61,'Sticker Design');
INSERT INTO `project_tag` VALUES (62,'Brochure Design');
INSERT INTO `project_tag` VALUES (63,'Poster Design');
INSERT INTO `project_tag` VALUES (64,'Creative Design');
INSERT INTO `project_tag` VALUES (65,'Tattoo Design');
INSERT INTO `project_tag` VALUES (66,'Life Coaching');
INSERT INTO `project_tag` VALUES (67,'Game Consoles');
INSERT INTO `project_tag` VALUES (68,'Inspections');
INSERT INTO `project_tag` VALUES (69,'Excel');
CREATE TABLE IF NOT EXISTS `project_semanticsearch` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`keyword`	varchar ( 100 ) NOT NULL
);
CREATE TABLE IF NOT EXISTS `project_project_tags` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`project_id`	integer NOT NULL,
	`tag_id`	integer NOT NULL,
	FOREIGN KEY(`project_id`) REFERENCES `project_project`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`tag_id`) REFERENCES `project_tag`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `project_project_tags` VALUES (1,1,59);
INSERT INTO `project_project_tags` VALUES (2,1,51);
INSERT INTO `project_project_tags` VALUES (3,1,68);
INSERT INTO `project_project_tags` VALUES (4,2,64);
INSERT INTO `project_project_tags` VALUES (5,2,52);
INSERT INTO `project_project_tags` VALUES (6,2,53);
INSERT INTO `project_project_tags` VALUES (7,2,54);
INSERT INTO `project_project_tags` VALUES (8,2,55);
INSERT INTO `project_project_tags` VALUES (9,2,57);
INSERT INTO `project_project_tags` VALUES (10,2,58);
INSERT INTO `project_project_tags` VALUES (22,6,53);
INSERT INTO `project_project_tags` VALUES (23,6,55);
INSERT INTO `project_project_tags` VALUES (24,7,50);
INSERT INTO `project_project_tags` VALUES (25,8,9);
INSERT INTO `project_project_tags` VALUES (26,9,15);
INSERT INTO `project_project_tags` VALUES (27,10,15);
INSERT INTO `project_project_tags` VALUES (28,11,30);
INSERT INTO `project_project_tags` VALUES (29,12,26);
INSERT INTO `project_project_tags` VALUES (30,12,27);
INSERT INTO `project_project_tags` VALUES (31,13,16);
INSERT INTO `project_project_tags` VALUES (32,13,51);
INSERT INTO `project_project_tags` VALUES (33,13,52);
INSERT INTO `project_project_tags` VALUES (34,13,54);
INSERT INTO `project_project_tags` VALUES (35,14,51);
INSERT INTO `project_project_tags` VALUES (36,14,52);
INSERT INTO `project_project_tags` VALUES (37,15,57);
INSERT INTO `project_project_tags` VALUES (38,16,64);
CREATE TABLE IF NOT EXISTS `project_project` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`title`	varchar ( 200 ) NOT NULL,
	`description`	text NOT NULL,
	`created_at`	datetime NOT NULL,
	`updated_at`	datetime NOT NULL,
	`budget_min`	integer NOT NULL,
	`budget_max`	integer NOT NULL,
	`deadline`	datetime NOT NULL,
	`user_id_id`	integer NOT NULL,
	`category_id`	integer NOT NULL,
	`file`	varchar ( 100 ) NOT NULL,
	`latitude`	decimal,
	`longitude`	decimal,
	`accepted_bid`	integer NOT NULL,
	FOREIGN KEY(`category_id`) REFERENCES `project_category`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`user_id_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `project_project` VALUES (1,'Need SDH Subtitler / Captioner','Hi Everyone,

We need SDH Subtitler / Captioner for English Movies/Series.

Requirements:

Must have profound knowledge in English

Must be able to understand literal or colloquial expressions of spoken English.

Should maintain the quality throughout the translation.

Should be able to work under pressure to meet the deadline.

You will have to take a sample test before awarding the project to test your translation skills.

This is a long term project so mention your translation rate per video minute in the bid proposal.

More details over Chat.','2019-01-02 15:22:41.889187','2019-01-02 15:22:41.889227',21,30,'2019-02-21 13:59:00',2,8,'',NULL,NULL,0);
INSERT INTO `project_project` VALUES (2,'Seeking Talented Cartoonist','We need 7 individual graphics created to build our brand.

Details have already been sent to the selected designer.','2019-01-02 15:24:18.029848','2019-01-02 15:24:18.029899',250,750,'2019-03-03 23:59:00',2,8,'',NULL,NULL,0);
INSERT INTO `project_project` VALUES (6,'Interior Design - STUDIO Project','I''m interested in a Interior design project for a studio apartment with 22m². The studio has a rectangular shape, with 7,5 metres by 3 meters. I would prefer if the design use elements from shops and brands near me, so I''ll be able to accomplish the project. I would prefer low cost brands as IKEA or LEROY MERLIN, or some other online shop that can delivers in Portugal. The budget for the project should not exceed 1.000 euros. I would be open to any styles and new ideias. The designer is welcome to change any features of the room, as the tile, floor, wallpaper, wall painting, doors and wardrobe painting, new lighting.','2019-01-02 15:37:05.753280','2019-01-02 15:37:05.753316',30,40,'2019-02-03 23:59:00',2,8,'',NULL,NULL,0);
INSERT INTO `project_project` VALUES (7,'3D animation for my lovely dog','<p>HELLO :D</p><p>I want you to create some beautiful 3D animations of my dear Grace as a super-dog or maybe dog-monster or even a space-dog so that all my book club friends can be jealous of her birthday party.</p><p>Please attach your previous work in the comments or leave a link to them as they will have a huge impact on my decision.</p><p>I hope I choose you &lt;3</p><p>Nice bidding y''all :))))</p>','2019-01-02 15:48:46.612438','2019-01-02 15:48:46.612478',500,1500,'2019-01-12 23:59:00',1,8,'files/dog.jpeg',NULL,NULL,0);
INSERT INTO `project_project` VALUES (8,'Programming teacher','<h1 class="ql-indent-1"><strong><em>Hi, I am looking for a good teacher to teach programming to my sons. I think the education should last at least a year. The student candidates are desired. I added the programming language as tag that I know. If you have any other suggestions about the language we can decide on that later.</em></strong></h1><p><br></p>','2019-01-02 15:52:44.489870','2019-01-02 15:52:44.489907',50,100,'2020-01-02 23:59:00',5,1,'',40.9666272,29.2689109,0);
INSERT INTO `project_project` VALUES (9,'Some simple animations for my blog','<p>I have a nice personal blog but it is a bit too boring. I need somebody to add it a bit of dynamicity.</p>','2019-01-02 16:15:49.998420','2019-01-02 16:15:49.998457',100,260,'2019-01-27 23:59:00',1,1,'',NULL,NULL,0);
INSERT INTO `project_project` VALUES (10,'Website for my coffee shop','<h1>I urgently need a simple design and application for my shop''s website. Everything related to logic has done already by another developer from this site. But he said that was his expertise and that he didn''t agreed upon visual stuff of the site. SO PLSSS HELP MEEE!!</h1>','2019-01-02 16:41:13.297903','2019-01-02 18:03:42.513511',800,1500,'2019-01-04 23:59:00',8,1,'',NULL,NULL,7);
INSERT INTO `project_project` VALUES (11,'Dummy project','<p>asdhflaskjdf; as;djf;asldkfm asdknf;asdfn	</p>','2019-01-02 16:59:01.280525','2019-01-02 16:59:50.130543',234,23422,'2019-01-19 23:59:00',10,4,'',NULL,NULL,6);
INSERT INTO `project_project` VALUES (12,'Build a stock market application for android and Ios','First read the description and only if you have knowledge about this then only send bid.

Requiremnets:

1. Knowledge of super trend indicator in stock market.

2. Knowledge of stock market (BSE, NSE).

I want to build an application in which we can add companies from NSE BSE then if supertrend indicator is hit then we will get notification.','2019-01-02 17:07:28.856012','2019-01-02 17:07:28.856048',400,600,'2019-04-30 17:00:00',13,2,'',NULL,NULL,0);
INSERT INTO `project_project` VALUES (13,'Gui Redesign and UI/UX (online aura photography)','Hi I want to develop new gui and ux/ui
ui=user interface
ux=user experience
please download following app
[login to view URL]
and see how u can help me to make it better

Requirement 
a) Take photo
b) take video
c) see photo
d) share photo
e)help
also i want none experience people to used app

I want to earn money from non professional using add
and professional using paid service','2019-01-02 17:08:34.192979','2019-01-02 17:08:34.193017',35,70,'2019-03-25 17:00:00',13,7,'',NULL,NULL,0);
INSERT INTO `project_project` VALUES (14,'1 minute 3D animation','Im looking for someone to do a 2D animation for my company

Here is the reference video','2019-01-02 17:10:22.945094','2019-01-02 17:10:22.945131',20,40,'2019-01-19 14:00:00',12,7,'',38,45,0);
INSERT INTO `project_project` VALUES (15,'I want to restore my daughter''s photo','<p>This is the photo. It is very important for me.</p><p><img src="http://18.130.93.29:8000/media/images/old-photos-that-need-restorati.jpg"></p>','2019-01-03 14:00:25.321150','2019-01-03 14:00:25.321188',50,100,'2019-02-08 23:59:00',15,7,'',NULL,NULL,0);
INSERT INTO `project_project` VALUES (16,'Interior Design For Restaurant','<p>I have a restaurant at Besiktas. I need an architect to do the decoration. We can talk about the details at my restaurant.</p>','2019-01-06 15:09:10.409685','2019-01-06 15:09:10.409723',3000,5000,'2019-04-11 23:59:00',16,8,'',41.044,29.002,0);
CREATE TABLE IF NOT EXISTS `project_milestone` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`description`	text NOT NULL,
	`amount`	integer NOT NULL,
	`created_at`	datetime NOT NULL,
	`updated_at`	datetime NOT NULL,
	`bid_id_id`	integer NOT NULL,
	`user_id_id`	integer NOT NULL,
	`deadline`	datetime NOT NULL,
	FOREIGN KEY(`bid_id_id`) REFERENCES `project_bid`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`user_id_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `project_milestone` VALUES (1,'3 of the graphics',300,'2019-01-02 15:48:39.022740','2019-01-02 15:48:39.022776',1,4,'2019-01-15 18:48:00');
INSERT INTO `project_milestone` VALUES (3,'Whole project will be done',25,'2019-01-02 16:05:58.989384','2019-01-02 16:05:58.989420',3,6,'2019-02-07 19:00:00');
INSERT INTO `project_milestone` VALUES (4,'Most of the part will be done.',150,'2019-01-02 16:24:14.506617','2019-01-02 16:24:14.506656',5,7,'2019-01-18 00:12:00');
INSERT INTO `project_milestone` VALUES (5,'sdjg''lskdmf sdflkgmsd;/lfg',234,'2019-01-02 16:59:38.974336','2019-01-02 16:59:38.974376',6,10,'2019-01-11 22:22:00');
INSERT INTO `project_milestone` VALUES (6,'sdvalsdkfa;/lskfasdmf',571,'2019-01-02 16:59:39.115902','2019-01-02 16:59:39.115940',6,10,'2019-01-16 00:00:00');
INSERT INTO `project_milestone` VALUES (7,'Working UI without much design.',250,'2019-01-02 18:03:03.978784','2019-01-02 18:03:03.978822',7,9,'2019-01-04 00:00:00');
INSERT INTO `project_milestone` VALUES (8,'Design improved and some thought put on the UX.',500,'2019-01-02 18:03:04.125173','2019-01-02 18:03:04.125208',7,9,'2019-01-06 00:00:00');
CREATE TABLE IF NOT EXISTS `project_category` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`title`	varchar ( 100 ) NOT NULL
);
INSERT INTO `project_category` VALUES (1,'Websites, IT and Software');
INSERT INTO `project_category` VALUES (2,'Mobile Phones and Computing');
INSERT INTO `project_category` VALUES (3,'Translation and Languages');
INSERT INTO `project_category` VALUES (4,'Engineering and Science');
INSERT INTO `project_category` VALUES (5,'Writing and Content');
INSERT INTO `project_category` VALUES (6,'Sales and Marketing');
INSERT INTO `project_category` VALUES (7,'Photography');
INSERT INTO `project_category` VALUES (8,'Design, Media and Architecture');
INSERT INTO `project_category` VALUES (9,'Other');
CREATE TABLE IF NOT EXISTS `project_bid` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`description`	text NOT NULL,
	`amount`	integer NOT NULL,
	`created_at`	datetime NOT NULL,
	`updated_at`	datetime NOT NULL,
	`project_id_id`	integer NOT NULL,
	`user_id_id`	integer NOT NULL,
	FOREIGN KEY(`user_id_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`project_id_id`) REFERENCES `project_project`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `project_bid` VALUES (1,'I believe I’m qualified for this job.',550,'2019-01-02 15:48:38.806770','2019-01-02 15:48:38.806810',2,4);
INSERT INTO `project_bid` VALUES (3,'I am the most complete cinematographer, in the world',25,'2019-01-02 16:05:58.852244','2019-01-02 16:05:58.852282',1,6);
INSERT INTO `project_bid` VALUES (4,'merhaba',0,'2019-01-02 16:10:27.273604','2019-01-02 16:10:27.273642',8,2);
INSERT INTO `project_bid` VALUES (5,'I spent my whole life with web development. If you believe me choose then :)',200,'2019-01-02 16:24:14.419924','2019-01-02 16:24:14.419969',9,7);
INSERT INTO `project_bid` VALUES (6,'gsdflgkjsd/fg',2345,'2019-01-02 16:59:38.829486','2019-01-02 16:59:38.829527',11,10);
INSERT INTO `project_bid` VALUES (7,'I am the best',900,'2019-01-02 18:03:03.836522','2019-01-02 18:03:03.836559',10,9);
INSERT INTO `project_bid` VALUES (8,'bid',0,'2019-01-02 18:13:13.865403','2019-01-02 18:13:13.865436',8,13);
CREATE TABLE IF NOT EXISTS `payment_wallet` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`budget`	integer NOT NULL,
	`user_id_id`	integer NOT NULL,
	FOREIGN KEY(`user_id_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `payment_wallet` VALUES (1,0,1);
INSERT INTO `payment_wallet` VALUES (2,0,2);
INSERT INTO `payment_wallet` VALUES (3,0,3);
INSERT INTO `payment_wallet` VALUES (4,0,4);
INSERT INTO `payment_wallet` VALUES (5,0,5);
INSERT INTO `payment_wallet` VALUES (6,0,6);
INSERT INTO `payment_wallet` VALUES (7,0,7);
INSERT INTO `payment_wallet` VALUES (8,0,8);
INSERT INTO `payment_wallet` VALUES (9,0,9);
INSERT INTO `payment_wallet` VALUES (10,0,10);
INSERT INTO `payment_wallet` VALUES (11,0,11);
INSERT INTO `payment_wallet` VALUES (12,0,12);
INSERT INTO `payment_wallet` VALUES (13,0,13);
INSERT INTO `payment_wallet` VALUES (14,5000,14);
INSERT INTO `payment_wallet` VALUES (15,0,15);
INSERT INTO `payment_wallet` VALUES (16,0,16);
CREATE TABLE IF NOT EXISTS `payment_payment` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`amount`	integer NOT NULL,
	`acceptedproject_id_id`	integer NOT NULL,
	FOREIGN KEY(`acceptedproject_id_id`) REFERENCES `acceptedProject_acceptedproject`(`id`) DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE IF NOT EXISTS `django_session` (
	`session_key`	varchar ( 40 ) NOT NULL,
	`session_data`	text NOT NULL,
	`expire_date`	datetime NOT NULL,
	PRIMARY KEY(`session_key`)
);
CREATE TABLE IF NOT EXISTS `django_migrations` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`app`	varchar ( 255 ) NOT NULL,
	`name`	varchar ( 255 ) NOT NULL,
	`applied`	datetime NOT NULL
);
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2019-01-02 14:53:59.619038');
INSERT INTO `django_migrations` VALUES (2,'contenttypes','0002_remove_content_type_name','2019-01-02 14:53:59.637318');
INSERT INTO `django_migrations` VALUES (3,'auth','0001_initial','2019-01-02 14:53:59.660850');
INSERT INTO `django_migrations` VALUES (4,'auth','0002_alter_permission_name_max_length','2019-01-02 14:53:59.676633');
INSERT INTO `django_migrations` VALUES (5,'auth','0003_alter_user_email_max_length','2019-01-02 14:53:59.686870');
INSERT INTO `django_migrations` VALUES (6,'auth','0004_alter_user_username_opts','2019-01-02 14:53:59.697508');
INSERT INTO `django_migrations` VALUES (7,'auth','0005_alter_user_last_login_null','2019-01-02 14:53:59.707752');
INSERT INTO `django_migrations` VALUES (8,'auth','0006_require_contenttypes_0002','2019-01-02 14:53:59.712367');
INSERT INTO `django_migrations` VALUES (9,'auth','0007_alter_validators_add_error_messages','2019-01-02 14:53:59.721207');
INSERT INTO `django_migrations` VALUES (10,'auth','0008_alter_user_username_max_length','2019-01-02 14:53:59.730163');
INSERT INTO `django_migrations` VALUES (11,'auth','0009_alter_user_last_name_max_length','2019-01-02 14:53:59.739425');
INSERT INTO `django_migrations` VALUES (12,'user','0001_initial','2019-01-02 14:53:59.774869');
INSERT INTO `django_migrations` VALUES (13,'project','0001_initial','2019-01-02 14:53:59.819375');
INSERT INTO `django_migrations` VALUES (14,'project','0002_auto_20181107_2357','2019-01-02 14:53:59.869823');
INSERT INTO `django_migrations` VALUES (15,'project','0003_bid_milestone','2019-01-02 14:53:59.907380');
INSERT INTO `django_migrations` VALUES (16,'project','0004_milestone_deadline','2019-01-02 14:53:59.932027');
INSERT INTO `django_migrations` VALUES (17,'project','0005_project_accepted_bid','2019-01-02 14:53:59.958260');
INSERT INTO `django_migrations` VALUES (18,'project','0006_remove_project_accepted_bid','2019-01-02 14:53:59.982897');
INSERT INTO `django_migrations` VALUES (19,'acceptedProject','0001_initial','2019-01-02 14:54:00.051760');
INSERT INTO `django_migrations` VALUES (20,'acceptedProject','0002_modelforbackend','2019-01-02 14:54:00.063249');
INSERT INTO `django_migrations` VALUES (21,'acceptedProject','0003_auto_20181128_1335','2019-01-02 14:54:00.091085');
INSERT INTO `django_migrations` VALUES (22,'acceptedProject','0004_auto_20181128_1336','2019-01-02 14:54:00.120827');
INSERT INTO `django_migrations` VALUES (23,'acceptedProject','0005_auto_20181128_1336','2019-01-02 14:54:00.167192');
INSERT INTO `django_migrations` VALUES (24,'acceptedProject','0006_auto_20181128_1339','2019-01-02 14:54:00.216407');
INSERT INTO `django_migrations` VALUES (25,'acceptedProject','0007_auto_20181128_1341','2019-01-02 14:54:00.246715');
INSERT INTO `django_migrations` VALUES (26,'acceptedProject','0008_auto_20181128_1341','2019-01-02 14:54:00.276504');
INSERT INTO `django_migrations` VALUES (27,'acceptedProject','0009_auto_20181128_1412','2019-01-02 14:54:00.324294');
INSERT INTO `django_migrations` VALUES (28,'acceptedProject','0010_modelforbackend_project_id','2019-01-02 14:54:00.336290');
INSERT INTO `django_migrations` VALUES (29,'acceptedProject','0011_modelforbackend_acceptedproject_id','2019-01-02 14:54:00.348403');
INSERT INTO `django_migrations` VALUES (30,'acceptedProject','0012_auto_20181129_0952','2019-01-02 14:54:00.361966');
INSERT INTO `django_migrations` VALUES (31,'acceptedProject','0013_auto_20181130_1708','2019-01-02 14:54:00.379830');
INSERT INTO `django_migrations` VALUES (32,'acceptedProject','0014_auto_20181130_1714','2019-01-02 14:54:00.461554');
INSERT INTO `django_migrations` VALUES (33,'acceptedProject','0015_auto_20181130_1716','2019-01-02 14:54:00.515197');
INSERT INTO `django_migrations` VALUES (34,'acceptedProject','0016_auto_20181209_1048','2019-01-02 14:54:00.596815');
INSERT INTO `django_migrations` VALUES (35,'admin','0001_initial','2019-01-02 14:54:00.623496');
INSERT INTO `django_migrations` VALUES (36,'admin','0002_logentry_remove_auto_add','2019-01-02 14:54:00.650710');
INSERT INTO `django_migrations` VALUES (37,'admin','0003_logentry_add_action_flag_choices','2019-01-02 14:54:00.678283');
INSERT INTO `django_migrations` VALUES (38,'annotation','0001_initial','2019-01-02 14:54:00.827029');
INSERT INTO `django_migrations` VALUES (39,'authtoken','0001_initial','2019-01-02 14:54:00.862068');
INSERT INTO `django_migrations` VALUES (40,'authtoken','0002_auto_20160226_1747','2019-01-02 14:54:00.953171');
INSERT INTO `django_migrations` VALUES (41,'user','0002_userprofile','2019-01-02 14:54:00.988436');
INSERT INTO `django_migrations` VALUES (42,'user','0003_auto_20181020_2030','2019-01-02 14:54:01.026705');
INSERT INTO `django_migrations` VALUES (43,'user','0004_userprofile_name','2019-01-02 14:54:01.058427');
INSERT INTO `django_migrations` VALUES (44,'user','0005_auto_20181026_1218','2019-01-02 14:54:01.125980');
INSERT INTO `django_migrations` VALUES (45,'user','0006_auto_20181026_1235','2019-01-02 14:54:01.163825');
INSERT INTO `django_migrations` VALUES (46,'user','0007_auto_20181026_1240','2019-01-02 14:54:01.202218');
INSERT INTO `django_migrations` VALUES (47,'user','0008_auto_20181026_1917','2019-01-02 14:54:01.233509');
INSERT INTO `django_migrations` VALUES (48,'user','0009_user_role','2019-01-02 14:54:01.266078');
INSERT INTO `django_migrations` VALUES (49,'user','0010_auto_20181125_1049','2019-01-02 14:54:01.343791');
INSERT INTO `django_migrations` VALUES (50,'comment','0001_initial','2019-01-02 14:54:01.407746');
INSERT INTO `django_migrations` VALUES (51,'payment','0001_initial','2019-01-02 14:54:01.471830');
INSERT INTO `django_migrations` VALUES (52,'project','0007_project_accepted_bid','2019-01-02 14:54:01.521796');
INSERT INTO `django_migrations` VALUES (53,'project','0008_semanticsearch','2019-01-02 14:54:01.533454');
INSERT INTO `django_migrations` VALUES (54,'sessions','0001_initial','2019-01-02 14:54:01.546348');
INSERT INTO `django_migrations` VALUES (55,'upload','0001_initial','2019-01-02 14:54:01.585613');
INSERT INTO `django_migrations` VALUES (56,'user','0011_auto_20190101_1307','2019-01-02 14:54:01.658804');
INSERT INTO `django_migrations` VALUES (57,'user','0012_auto_20190102_0842','2019-01-02 14:54:01.791725');
CREATE TABLE IF NOT EXISTS `django_content_type` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`app_label`	varchar ( 100 ) NOT NULL,
	`model`	varchar ( 100 ) NOT NULL
);
INSERT INTO `django_content_type` VALUES (1,'admin','logentry');
INSERT INTO `django_content_type` VALUES (2,'auth','permission');
INSERT INTO `django_content_type` VALUES (3,'auth','group');
INSERT INTO `django_content_type` VALUES (4,'contenttypes','contenttype');
INSERT INTO `django_content_type` VALUES (5,'sessions','session');
INSERT INTO `django_content_type` VALUES (6,'authtoken','token');
INSERT INTO `django_content_type` VALUES (7,'user','user');
INSERT INTO `django_content_type` VALUES (8,'user','clientprofile');
INSERT INTO `django_content_type` VALUES (9,'user','freelancerprofile');
INSERT INTO `django_content_type` VALUES (10,'project','category');
INSERT INTO `django_content_type` VALUES (11,'project','project');
INSERT INTO `django_content_type` VALUES (12,'project','tag');
INSERT INTO `django_content_type` VALUES (13,'project','bid');
INSERT INTO `django_content_type` VALUES (14,'project','milestone');
INSERT INTO `django_content_type` VALUES (15,'project','semanticsearch');
INSERT INTO `django_content_type` VALUES (16,'comment','clientcomment');
INSERT INTO `django_content_type` VALUES (17,'comment','freelancercomment');
INSERT INTO `django_content_type` VALUES (18,'acceptedProject','acceptedmilestone');
INSERT INTO `django_content_type` VALUES (19,'acceptedProject','acceptedproject');
INSERT INTO `django_content_type` VALUES (20,'acceptedProject','modelforbackend');
INSERT INTO `django_content_type` VALUES (21,'payment','payment');
INSERT INTO `django_content_type` VALUES (22,'payment','wallet');
INSERT INTO `django_content_type` VALUES (23,'annotation','body');
INSERT INTO `django_content_type` VALUES (24,'annotation','fragmentselector');
INSERT INTO `django_content_type` VALUES (25,'annotation','imageannotation');
INSERT INTO `django_content_type` VALUES (26,'annotation','imagetarget');
INSERT INTO `django_content_type` VALUES (27,'annotation','refinedby');
INSERT INTO `django_content_type` VALUES (28,'annotation','selector');
INSERT INTO `django_content_type` VALUES (29,'annotation','startendselector');
INSERT INTO `django_content_type` VALUES (30,'annotation','target');
INSERT INTO `django_content_type` VALUES (31,'annotation','textannotation');
INSERT INTO `django_content_type` VALUES (32,'upload','uploadimage');
CREATE TABLE IF NOT EXISTS `django_admin_log` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`action_time`	datetime NOT NULL,
	`object_id`	text,
	`object_repr`	varchar ( 200 ) NOT NULL,
	`change_message`	text NOT NULL,
	`content_type_id`	integer,
	`user_id`	integer NOT NULL,
	`action_flag`	smallint unsigned NOT NULL,
	FOREIGN KEY(`content_type_id`) REFERENCES `django_content_type`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`user_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE IF NOT EXISTS `comment_freelancercomment` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`description`	text NOT NULL,
	`created_at`	datetime NOT NULL,
	`updated_at`	datetime NOT NULL,
	`profile_id_id`	integer NOT NULL,
	`user_id_id`	integer NOT NULL,
	FOREIGN KEY(`user_id_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`profile_id_id`) REFERENCES `user_freelancerprofile`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `comment_freelancercomment` VALUES (1,'I liked your github profile.','2019-01-06 14:56:50.358552','2019-01-06 14:56:50.358602',14,16);
CREATE TABLE IF NOT EXISTS `comment_clientcomment` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`description`	text NOT NULL,
	`created_at`	datetime NOT NULL,
	`updated_at`	datetime NOT NULL,
	`profile_id_id`	integer NOT NULL,
	`user_id_id`	integer NOT NULL,
	FOREIGN KEY(`profile_id_id`) REFERENCES `user_clientprofile`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`user_id_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `comment_clientcomment` VALUES (1,'kimsin sen?','2019-01-02 17:52:16.569269','2019-01-02 17:52:16.569305',10,13);
CREATE TABLE IF NOT EXISTS `authtoken_token` (
	`key`	varchar ( 40 ) NOT NULL,
	`created`	datetime NOT NULL,
	`user_id`	integer NOT NULL UNIQUE,
	PRIMARY KEY(`key`),
	FOREIGN KEY(`user_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `authtoken_token` VALUES ('72aac86d0058210ae7e7c4e41e35305dc8037b7b','2019-01-02 14:54:36.084743',1);
INSERT INTO `authtoken_token` VALUES ('959ca7f8f70f8514184ae481234777662c3bd416','2019-01-02 15:04:35.046637',2);
INSERT INTO `authtoken_token` VALUES ('18db1512f1be33dd181e483f1372c87c6c2e4e61','2019-01-02 15:20:07.504829',3);
INSERT INTO `authtoken_token` VALUES ('0e6b9dfe10fc0b39383ccf302347b61c46870e8e','2019-01-02 15:34:17.121908',4);
INSERT INTO `authtoken_token` VALUES ('4c8679c6070186bafe4e7c9e8c5bdebd4b76be9e','2019-01-02 15:37:07.804618',5);
INSERT INTO `authtoken_token` VALUES ('7232c7d6e7b09f8f3991f79a59bf990e7a31dbfa','2019-01-02 16:00:17.011555',6);
INSERT INTO `authtoken_token` VALUES ('58425d2da3f86739838c7a0ce886d652d9b63c71','2019-01-02 16:16:39.025295',7);
INSERT INTO `authtoken_token` VALUES ('f429399fc03b9e7cedf08d75e9fb0ac585f3ebe7','2019-01-02 16:35:44.601417',8);
INSERT INTO `authtoken_token` VALUES ('6d25f891f67d0fe286db3b9986b81fcc665751d5','2019-01-02 16:42:59.421919',9);
INSERT INTO `authtoken_token` VALUES ('a7e72130aeef3687fb2b3bd770f189a3e167f6c5','2019-01-02 16:55:05.859996',10);
INSERT INTO `authtoken_token` VALUES ('094a935a956f592b0cd0bd5a3f73cbe4f88ae4b0','2019-01-02 17:05:52.976984',13);
INSERT INTO `authtoken_token` VALUES ('6f08bdcd3d8135e6600b687e2e12f38d65222699','2019-01-02 17:09:20.695826',12);
INSERT INTO `authtoken_token` VALUES ('ea7295f01357a5aa398f1babe2eadcc8efa4bbcf','2019-01-02 20:35:34.873304',14);
INSERT INTO `authtoken_token` VALUES ('878b4c00510323b92b09438491652ac50125cca0','2019-01-03 13:41:31.408388',15);
INSERT INTO `authtoken_token` VALUES ('2183f51f8fdfa1b390e6fefe6c446435e2ebf499','2019-01-03 14:32:19.153183',11);
INSERT INTO `authtoken_token` VALUES ('9b9588c68241fb15c16a51738a56e01c258aa99f','2019-01-06 14:38:49.755010',16);
CREATE TABLE IF NOT EXISTS `auth_permission` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`content_type_id`	integer NOT NULL,
	`codename`	varchar ( 100 ) NOT NULL,
	`name`	varchar ( 255 ) NOT NULL,
	FOREIGN KEY(`content_type_id`) REFERENCES `django_content_type`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `auth_permission` VALUES (1,1,'add_logentry','Can add log entry');
INSERT INTO `auth_permission` VALUES (2,1,'change_logentry','Can change log entry');
INSERT INTO `auth_permission` VALUES (3,1,'delete_logentry','Can delete log entry');
INSERT INTO `auth_permission` VALUES (4,1,'view_logentry','Can view log entry');
INSERT INTO `auth_permission` VALUES (5,2,'add_permission','Can add permission');
INSERT INTO `auth_permission` VALUES (6,2,'change_permission','Can change permission');
INSERT INTO `auth_permission` VALUES (7,2,'delete_permission','Can delete permission');
INSERT INTO `auth_permission` VALUES (8,2,'view_permission','Can view permission');
INSERT INTO `auth_permission` VALUES (9,3,'add_group','Can add group');
INSERT INTO `auth_permission` VALUES (10,3,'change_group','Can change group');
INSERT INTO `auth_permission` VALUES (11,3,'delete_group','Can delete group');
INSERT INTO `auth_permission` VALUES (12,3,'view_group','Can view group');
INSERT INTO `auth_permission` VALUES (13,4,'add_contenttype','Can add content type');
INSERT INTO `auth_permission` VALUES (14,4,'change_contenttype','Can change content type');
INSERT INTO `auth_permission` VALUES (15,4,'delete_contenttype','Can delete content type');
INSERT INTO `auth_permission` VALUES (16,4,'view_contenttype','Can view content type');
INSERT INTO `auth_permission` VALUES (17,5,'add_session','Can add session');
INSERT INTO `auth_permission` VALUES (18,5,'change_session','Can change session');
INSERT INTO `auth_permission` VALUES (19,5,'delete_session','Can delete session');
INSERT INTO `auth_permission` VALUES (20,5,'view_session','Can view session');
INSERT INTO `auth_permission` VALUES (21,6,'add_token','Can add Token');
INSERT INTO `auth_permission` VALUES (22,6,'change_token','Can change Token');
INSERT INTO `auth_permission` VALUES (23,6,'delete_token','Can delete Token');
INSERT INTO `auth_permission` VALUES (24,6,'view_token','Can view Token');
INSERT INTO `auth_permission` VALUES (25,7,'add_user','Can add user');
INSERT INTO `auth_permission` VALUES (26,7,'change_user','Can change user');
INSERT INTO `auth_permission` VALUES (27,7,'delete_user','Can delete user');
INSERT INTO `auth_permission` VALUES (28,7,'view_user','Can view user');
INSERT INTO `auth_permission` VALUES (29,8,'add_clientprofile','Can add client profile');
INSERT INTO `auth_permission` VALUES (30,8,'change_clientprofile','Can change client profile');
INSERT INTO `auth_permission` VALUES (31,8,'delete_clientprofile','Can delete client profile');
INSERT INTO `auth_permission` VALUES (32,8,'view_clientprofile','Can view client profile');
INSERT INTO `auth_permission` VALUES (33,9,'add_freelancerprofile','Can add freelancer profile');
INSERT INTO `auth_permission` VALUES (34,9,'change_freelancerprofile','Can change freelancer profile');
INSERT INTO `auth_permission` VALUES (35,9,'delete_freelancerprofile','Can delete freelancer profile');
INSERT INTO `auth_permission` VALUES (36,9,'view_freelancerprofile','Can view freelancer profile');
INSERT INTO `auth_permission` VALUES (37,10,'add_category','Can add category');
INSERT INTO `auth_permission` VALUES (38,10,'change_category','Can change category');
INSERT INTO `auth_permission` VALUES (39,10,'delete_category','Can delete category');
INSERT INTO `auth_permission` VALUES (40,10,'view_category','Can view category');
INSERT INTO `auth_permission` VALUES (41,11,'add_project','Can add project');
INSERT INTO `auth_permission` VALUES (42,11,'change_project','Can change project');
INSERT INTO `auth_permission` VALUES (43,11,'delete_project','Can delete project');
INSERT INTO `auth_permission` VALUES (44,11,'view_project','Can view project');
INSERT INTO `auth_permission` VALUES (45,12,'add_tag','Can add tag');
INSERT INTO `auth_permission` VALUES (46,12,'change_tag','Can change tag');
INSERT INTO `auth_permission` VALUES (47,12,'delete_tag','Can delete tag');
INSERT INTO `auth_permission` VALUES (48,12,'view_tag','Can view tag');
INSERT INTO `auth_permission` VALUES (49,13,'add_bid','Can add bid');
INSERT INTO `auth_permission` VALUES (50,13,'change_bid','Can change bid');
INSERT INTO `auth_permission` VALUES (51,13,'delete_bid','Can delete bid');
INSERT INTO `auth_permission` VALUES (52,13,'view_bid','Can view bid');
INSERT INTO `auth_permission` VALUES (53,14,'add_milestone','Can add milestone');
INSERT INTO `auth_permission` VALUES (54,14,'change_milestone','Can change milestone');
INSERT INTO `auth_permission` VALUES (55,14,'delete_milestone','Can delete milestone');
INSERT INTO `auth_permission` VALUES (56,14,'view_milestone','Can view milestone');
INSERT INTO `auth_permission` VALUES (57,15,'add_semanticsearch','Can add semantic search');
INSERT INTO `auth_permission` VALUES (58,15,'change_semanticsearch','Can change semantic search');
INSERT INTO `auth_permission` VALUES (59,15,'delete_semanticsearch','Can delete semantic search');
INSERT INTO `auth_permission` VALUES (60,15,'view_semanticsearch','Can view semantic search');
INSERT INTO `auth_permission` VALUES (61,16,'add_clientcomment','Can add client comment');
INSERT INTO `auth_permission` VALUES (62,16,'change_clientcomment','Can change client comment');
INSERT INTO `auth_permission` VALUES (63,16,'delete_clientcomment','Can delete client comment');
INSERT INTO `auth_permission` VALUES (64,16,'view_clientcomment','Can view client comment');
INSERT INTO `auth_permission` VALUES (65,17,'add_freelancercomment','Can add freelancer comment');
INSERT INTO `auth_permission` VALUES (66,17,'change_freelancercomment','Can change freelancer comment');
INSERT INTO `auth_permission` VALUES (67,17,'delete_freelancercomment','Can delete freelancer comment');
INSERT INTO `auth_permission` VALUES (68,17,'view_freelancercomment','Can view freelancer comment');
INSERT INTO `auth_permission` VALUES (69,18,'add_acceptedmilestone','Can add accepted milestone');
INSERT INTO `auth_permission` VALUES (70,18,'change_acceptedmilestone','Can change accepted milestone');
INSERT INTO `auth_permission` VALUES (71,18,'delete_acceptedmilestone','Can delete accepted milestone');
INSERT INTO `auth_permission` VALUES (72,18,'view_acceptedmilestone','Can view accepted milestone');
INSERT INTO `auth_permission` VALUES (73,19,'add_acceptedproject','Can add accepted project');
INSERT INTO `auth_permission` VALUES (74,19,'change_acceptedproject','Can change accepted project');
INSERT INTO `auth_permission` VALUES (75,19,'delete_acceptedproject','Can delete accepted project');
INSERT INTO `auth_permission` VALUES (76,19,'view_acceptedproject','Can view accepted project');
INSERT INTO `auth_permission` VALUES (77,20,'add_modelforbackend','Can add model for backend');
INSERT INTO `auth_permission` VALUES (78,20,'change_modelforbackend','Can change model for backend');
INSERT INTO `auth_permission` VALUES (79,20,'delete_modelforbackend','Can delete model for backend');
INSERT INTO `auth_permission` VALUES (80,20,'view_modelforbackend','Can view model for backend');
INSERT INTO `auth_permission` VALUES (81,21,'add_payment','Can add payment');
INSERT INTO `auth_permission` VALUES (82,21,'change_payment','Can change payment');
INSERT INTO `auth_permission` VALUES (83,21,'delete_payment','Can delete payment');
INSERT INTO `auth_permission` VALUES (84,21,'view_payment','Can view payment');
INSERT INTO `auth_permission` VALUES (85,22,'add_wallet','Can add wallet');
INSERT INTO `auth_permission` VALUES (86,22,'change_wallet','Can change wallet');
INSERT INTO `auth_permission` VALUES (87,22,'delete_wallet','Can delete wallet');
INSERT INTO `auth_permission` VALUES (88,22,'view_wallet','Can view wallet');
INSERT INTO `auth_permission` VALUES (89,23,'add_body','Can add body');
INSERT INTO `auth_permission` VALUES (90,23,'change_body','Can change body');
INSERT INTO `auth_permission` VALUES (91,23,'delete_body','Can delete body');
INSERT INTO `auth_permission` VALUES (92,23,'view_body','Can view body');
INSERT INTO `auth_permission` VALUES (93,24,'add_fragmentselector','Can add fragment selector');
INSERT INTO `auth_permission` VALUES (94,24,'change_fragmentselector','Can change fragment selector');
INSERT INTO `auth_permission` VALUES (95,24,'delete_fragmentselector','Can delete fragment selector');
INSERT INTO `auth_permission` VALUES (96,24,'view_fragmentselector','Can view fragment selector');
INSERT INTO `auth_permission` VALUES (97,25,'add_imageannotation','Can add image annotation');
INSERT INTO `auth_permission` VALUES (98,25,'change_imageannotation','Can change image annotation');
INSERT INTO `auth_permission` VALUES (99,25,'delete_imageannotation','Can delete image annotation');
INSERT INTO `auth_permission` VALUES (100,25,'view_imageannotation','Can view image annotation');
INSERT INTO `auth_permission` VALUES (101,26,'add_imagetarget','Can add image target');
INSERT INTO `auth_permission` VALUES (102,26,'change_imagetarget','Can change image target');
INSERT INTO `auth_permission` VALUES (103,26,'delete_imagetarget','Can delete image target');
INSERT INTO `auth_permission` VALUES (104,26,'view_imagetarget','Can view image target');
INSERT INTO `auth_permission` VALUES (105,27,'add_refinedby','Can add refined by');
INSERT INTO `auth_permission` VALUES (106,27,'change_refinedby','Can change refined by');
INSERT INTO `auth_permission` VALUES (107,27,'delete_refinedby','Can delete refined by');
INSERT INTO `auth_permission` VALUES (108,27,'view_refinedby','Can view refined by');
INSERT INTO `auth_permission` VALUES (109,28,'add_selector','Can add selector');
INSERT INTO `auth_permission` VALUES (110,28,'change_selector','Can change selector');
INSERT INTO `auth_permission` VALUES (111,28,'delete_selector','Can delete selector');
INSERT INTO `auth_permission` VALUES (112,28,'view_selector','Can view selector');
INSERT INTO `auth_permission` VALUES (113,29,'add_startendselector','Can add start end selector');
INSERT INTO `auth_permission` VALUES (114,29,'change_startendselector','Can change start end selector');
INSERT INTO `auth_permission` VALUES (115,29,'delete_startendselector','Can delete start end selector');
INSERT INTO `auth_permission` VALUES (116,29,'view_startendselector','Can view start end selector');
INSERT INTO `auth_permission` VALUES (117,30,'add_target','Can add target');
INSERT INTO `auth_permission` VALUES (118,30,'change_target','Can change target');
INSERT INTO `auth_permission` VALUES (119,30,'delete_target','Can delete target');
INSERT INTO `auth_permission` VALUES (120,30,'view_target','Can view target');
INSERT INTO `auth_permission` VALUES (121,31,'add_textannotation','Can add text annotation');
INSERT INTO `auth_permission` VALUES (122,31,'change_textannotation','Can change text annotation');
INSERT INTO `auth_permission` VALUES (123,31,'delete_textannotation','Can delete text annotation');
INSERT INTO `auth_permission` VALUES (124,31,'view_textannotation','Can view text annotation');
INSERT INTO `auth_permission` VALUES (125,32,'add_uploadimage','Can add upload image');
INSERT INTO `auth_permission` VALUES (126,32,'change_uploadimage','Can change upload image');
INSERT INTO `auth_permission` VALUES (127,32,'delete_uploadimage','Can delete upload image');
INSERT INTO `auth_permission` VALUES (128,32,'view_uploadimage','Can view upload image');
CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`group_id`	integer NOT NULL,
	`permission_id`	integer NOT NULL,
	FOREIGN KEY(`group_id`) REFERENCES `auth_group`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`permission_id`) REFERENCES `auth_permission`(`id`) DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE IF NOT EXISTS `auth_group` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`name`	varchar ( 80 ) NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS `annotation_textannotation` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`motivation`	text NOT NULL,
	`created`	datetime NOT NULL,
	`body_id`	integer NOT NULL,
	`target_id`	integer NOT NULL,
	`user_id`	integer NOT NULL,
	FOREIGN KEY(`user_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`body_id`) REFERENCES `annotation_body`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`target_id`) REFERENCES `annotation_target`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `annotation_textannotation` VALUES (1,'commenting','2019-01-02 15:55:31.097940',1,1,5);
INSERT INTO `annotation_textannotation` VALUES (2,'commenting','2019-01-02 15:57:36.229709',3,2,1);
INSERT INTO `annotation_textannotation` VALUES (4,'questioning','2019-01-02 16:15:52.728952',9,4,6);
INSERT INTO `annotation_textannotation` VALUES (5,'commenting','2019-01-02 16:27:09.092670',10,5,7);
INSERT INTO `annotation_textannotation` VALUES (6,'assessing','2019-01-02 16:37:20.076502',13,6,7);
INSERT INTO `annotation_textannotation` VALUES (7,'highlighting','2019-01-02 17:28:08.568953',14,7,6);
INSERT INTO `annotation_textannotation` VALUES (8,'questioning','2019-01-02 18:09:23.244679',15,8,8);
CREATE TABLE IF NOT EXISTS `annotation_target` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`source`	text NOT NULL,
	`selector_id`	integer NOT NULL,
	FOREIGN KEY(`selector_id`) REFERENCES `annotation_selector`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `annotation_target` VALUES (1,'http://18.130.93.29:8080/profile',1);
INSERT INTO `annotation_target` VALUES (2,'http://18.130.93.29:8080/project/8',2);
INSERT INTO `annotation_target` VALUES (3,'http://18.130.93.29:8080/project/1',3);
INSERT INTO `annotation_target` VALUES (4,'http://18.130.93.29:8080/project/1',4);
INSERT INTO `annotation_target` VALUES (5,'http://18.130.93.29:8080/project/8',5);
INSERT INTO `annotation_target` VALUES (6,'http://18.130.93.29:8080/project/5',6);
INSERT INTO `annotation_target` VALUES (7,'http://18.130.93.29:8080/profile/10',7);
INSERT INTO `annotation_target` VALUES (8,'http://18.130.93.29:8080/project/9',8);
CREATE TABLE IF NOT EXISTS `annotation_startendselector` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`value`	text NOT NULL,
	`refinedBy_id`	integer NOT NULL,
	FOREIGN KEY(`refinedBy_id`) REFERENCES `annotation_refinedby`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `annotation_startendselector` VALUES (1,'//*[@id="app"]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[2]/a[1]/text()[1]',1);
INSERT INTO `annotation_startendselector` VALUES (2,'//*[@id="app"]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[2]/a[1]/text()[1]',2);
INSERT INTO `annotation_startendselector` VALUES (3,'//*[@id="description"]/div[1]/div[1]/div[1]/h1[1]/strong[1]/em[1]/text()[1]',3);
INSERT INTO `annotation_startendselector` VALUES (4,'//*[@id="description"]/div[1]/div[1]/div[1]/h1[1]/strong[1]/em[1]/text()[1]',4);
INSERT INTO `annotation_startendselector` VALUES (5,'//*[@id="description"]/div[1]/div[1]/div[1]/text()[1]',5);
INSERT INTO `annotation_startendselector` VALUES (6,'//*[@id="description"]/div[1]/div[1]/div[1]/text()[1]',6);
INSERT INTO `annotation_startendselector` VALUES (7,'//*[@id="description"]/div[1]/div[1]/div[1]/text()[1]',7);
INSERT INTO `annotation_startendselector` VALUES (8,'//*[@id="description"]/div[1]/div[1]/div[1]/text()[1]',8);
INSERT INTO `annotation_startendselector` VALUES (9,'//*[@id="description"]/div[1]/div[1]/div[1]/h1[1]/strong[1]/em[1]/text()[1]',9);
INSERT INTO `annotation_startendselector` VALUES (10,'//*[@id="description"]/div[1]/div[1]/div[1]/h1[1]/strong[1]/em[1]/text()[1]',10);
INSERT INTO `annotation_startendselector` VALUES (11,'//*[@id="title"]/text()[1]',11);
INSERT INTO `annotation_startendselector` VALUES (12,'//*[@id="title"]/text()[1]',12);
INSERT INTO `annotation_startendselector` VALUES (13,'//*[@id="app"]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/p[1]/text()[1]',13);
INSERT INTO `annotation_startendselector` VALUES (14,'//*[@id="app"]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/p[1]/text()[1]',14);
INSERT INTO `annotation_startendselector` VALUES (15,'//*[@id="project-info"]/div[1]/div[1]/div[2]/div[1]/text()[1]',15);
INSERT INTO `annotation_startendselector` VALUES (16,'//*[@id="project-info"]/div[1]/div[1]/div[2]/div[1]/text()[1]',16);
CREATE TABLE IF NOT EXISTS `annotation_selector` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`endSelector_id`	integer NOT NULL,
	`startSelector_id`	integer NOT NULL,
	FOREIGN KEY(`startSelector_id`) REFERENCES `annotation_startendselector`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`endSelector_id`) REFERENCES `annotation_startendselector`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `annotation_selector` VALUES (1,2,1);
INSERT INTO `annotation_selector` VALUES (2,4,3);
INSERT INTO `annotation_selector` VALUES (3,6,5);
INSERT INTO `annotation_selector` VALUES (4,8,7);
INSERT INTO `annotation_selector` VALUES (5,10,9);
INSERT INTO `annotation_selector` VALUES (6,12,11);
INSERT INTO `annotation_selector` VALUES (7,14,13);
INSERT INTO `annotation_selector` VALUES (8,16,15);
CREATE TABLE IF NOT EXISTS `annotation_refinedby` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`start`	integer NOT NULL,
	`end`	integer NOT NULL
);
INSERT INTO `annotation_refinedby` VALUES (1,0,4);
INSERT INTO `annotation_refinedby` VALUES (2,0,4);
INSERT INTO `annotation_refinedby` VALUES (3,208,290);
INSERT INTO `annotation_refinedby` VALUES (4,208,290);
INSERT INTO `annotation_refinedby` VALUES (5,123,130);
INSERT INTO `annotation_refinedby` VALUES (6,123,130);
INSERT INTO `annotation_refinedby` VALUES (7,203,210);
INSERT INTO `annotation_refinedby` VALUES (8,203,210);
INSERT INTO `annotation_refinedby` VALUES (9,0,68);
INSERT INTO `annotation_refinedby` VALUES (10,0,68);
INSERT INTO `annotation_refinedby` VALUES (11,0,32);
INSERT INTO `annotation_refinedby` VALUES (12,0,32);
INSERT INTO `annotation_refinedby` VALUES (13,0,9);
INSERT INTO `annotation_refinedby` VALUES (14,0,9);
INSERT INTO `annotation_refinedby` VALUES (15,0,9);
INSERT INTO `annotation_refinedby` VALUES (16,0,9);
CREATE TABLE IF NOT EXISTS `annotation_imagetarget` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`source`	text NOT NULL,
	`scope`	text NOT NULL,
	`selector_id`	integer NOT NULL,
	FOREIGN KEY(`selector_id`) REFERENCES `annotation_fragmentselector`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `annotation_imagetarget` VALUES (1,'http://18.130.93.29:8000/media/images/fft99_mf3657141.Jpeg','http://18.130.93.29:8080/profile',1);
INSERT INTO `annotation_imagetarget` VALUES (2,'http://18.130.93.29:8000/media/images/yinyang_noisy.png','http://18.130.93.29:8080/profile',2);
INSERT INTO `annotation_imagetarget` VALUES (3,'http://18.130.93.29:8000/media/images/yinyang_noisy.png','http://18.130.93.29:8080/profile',3);
INSERT INTO `annotation_imagetarget` VALUES (4,'https://maps.gstatic.com/mapfiles/api-3/images/spotlight-poi2.png','http://18.130.93.29:8080/project/8',4);
INSERT INTO `annotation_imagetarget` VALUES (5,'http://18.130.93.29:8000/media/images/canberk.jpg','http://18.130.93.29:8080/profile',5);
INSERT INTO `annotation_imagetarget` VALUES (6,'http://18.130.93.29:8000/media/images/vfor.jpeg','http://18.130.93.29:8080/profile/7',6);
INSERT INTO `annotation_imagetarget` VALUES (7,'http://18.130.93.29:8000/media/images/yinyang_noisy.png','http://18.130.93.29:8080/profile/1',7);
INSERT INTO `annotation_imagetarget` VALUES (8,'http://18.130.93.29:8000/media/images/lena200.png','http://18.130.93.29:8080/profile',8);
INSERT INTO `annotation_imagetarget` VALUES (9,'http://18.130.93.29:8000/media/images/old-photos-that-need-restorati.jpg','http://18.130.93.29:8080/project/15',9);
CREATE TABLE IF NOT EXISTS `annotation_imageannotation` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`motivation`	text NOT NULL,
	`created`	datetime NOT NULL,
	`body_id`	integer NOT NULL,
	`target_id`	integer NOT NULL,
	`user_id`	integer NOT NULL,
	FOREIGN KEY(`body_id`) REFERENCES `annotation_body`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`user_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`target_id`) REFERENCES `annotation_imagetarget`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `annotation_imageannotation` VALUES (1,'tagging','2019-01-02 15:56:05.747093',2,1,5);
INSERT INTO `annotation_imageannotation` VALUES (2,'questioning','2019-01-02 16:04:11.693295',4,2,1);
INSERT INTO `annotation_imageannotation` VALUES (3,'questioning','2019-01-02 16:05:12.041908',5,3,1);
INSERT INTO `annotation_imageannotation` VALUES (4,'questioning','2019-01-02 16:10:47.390528',6,4,6);
INSERT INTO `annotation_imageannotation` VALUES (5,'questioning','2019-01-02 16:13:45.186509',7,5,6);
INSERT INTO `annotation_imageannotation` VALUES (6,'questioning','2019-01-02 16:29:52.087630',11,6,6);
INSERT INTO `annotation_imageannotation` VALUES (7,'questioning','2019-01-02 16:30:40.459960',12,7,6);
INSERT INTO `annotation_imageannotation` VALUES (8,'describing','2019-01-02 18:09:54.665410',16,8,8);
INSERT INTO `annotation_imageannotation` VALUES (9,'questioning','2019-01-03 14:01:06.013872',17,9,15);
CREATE TABLE IF NOT EXISTS `annotation_fragmentselector` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`value`	text NOT NULL
);
INSERT INTO `annotation_fragmentselector` VALUES (1,'xywh=92,28,440,251');
INSERT INTO `annotation_fragmentselector` VALUES (2,'xywh=50,50,100,100');
INSERT INTO `annotation_fragmentselector` VALUES (3,'xywh=50,50,100,100');
INSERT INTO `annotation_fragmentselector` VALUES (4,'xywh=7,11,14,22');
INSERT INTO `annotation_fragmentselector` VALUES (5,'xywh=258,358,517,716');
INSERT INTO `annotation_fragmentselector` VALUES (6,'xywh=48,65,97,130');
INSERT INTO `annotation_fragmentselector` VALUES (7,'xywh=50,50,100,100');
INSERT INTO `annotation_fragmentselector` VALUES (8,'xywh=50,50,100,100');
INSERT INTO `annotation_fragmentselector` VALUES (9,'xywh=169,23,173,207');
CREATE TABLE IF NOT EXISTS `annotation_body` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`value`	text NOT NULL
);
INSERT INTO `annotation_body` VALUES (1,'<p>This is not a field I am interested in, it is a field that I want my sons to be interested in :)</p>');
INSERT INTO `annotation_body` VALUES (2,'<p>Photo is real :) </p>');
INSERT INTO `annotation_body` VALUES (3,'<p>I think you should consider having a general talk about programming with an expert first. It seems like you are not sure about the purpose of these lessons. So decide on that imho. If you can not find anybody to ask I would be glad to help :)</p>');
INSERT INTO `annotation_body` VALUES (4,'<p>Isn''t  this pic a bit too noisy? I recommand you to complete your CMPE 300 project and then use it on this dirty piece of inner peace...</p>');
INSERT INTO `annotation_body` VALUES (5,'<p>Isn''t  this pic a bit too noisy? I recommend you to complete your CMPE 300 project and then use it on this dirty piece of inner peace...</p>');
INSERT INTO `annotation_body` VALUES (6,'<p>How can i come there with bus?</p>');
INSERT INTO `annotation_body` VALUES (7,'<p>How am i looking?</p>');
INSERT INTO `annotation_body` VALUES (8,'<p>Which level do you want?</p>');
INSERT INTO `annotation_body` VALUES (9,'<p>Which level do you want?</p>');
INSERT INTO `annotation_body` VALUES (10,'<p>Haha, you mean baby sitter </p><p><img src="http://18.130.93.29:8000/media/images/download.jpeg"></p>');
INSERT INTO `annotation_body` VALUES (11,'<p>Is annotation working?</p>');
INSERT INTO `annotation_body` VALUES (12,'<p>Is it CmpE300?</p>');
INSERT INTO `annotation_body` VALUES (13,'<p>Ok bro, we got it, you are looking for an interior design. you don''t need create thousands of clones of the same project.</p>');
INSERT INTO `annotation_body` VALUES (14,'<p>asdfasdfs</p>');
INSERT INTO `annotation_body` VALUES (15,'<p>This amount is too small. I can do the project only if you double the budget.</p><p>I will still put a bid to give <strong>you</strong> some clue.</p>');
INSERT INTO `annotation_body` VALUES (16,'<p>Hi</p>');
INSERT INTO `annotation_body` VALUES (17,'<p>This part is missing. Can you still do it?</p>');
CREATE TABLE IF NOT EXISTS `acceptedProject_modelforbackend` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`accepted_bid`	integer NOT NULL
);
CREATE TABLE IF NOT EXISTS `acceptedProject_acceptedproject` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`title`	varchar ( 200 ) NOT NULL,
	`description`	text NOT NULL,
	`created_at`	datetime NOT NULL,
	`updated_at`	datetime NOT NULL,
	`price`	integer,
	`deadline`	datetime,
	`file`	varchar ( 100 ) NOT NULL,
	`latitude`	decimal,
	`longitude`	decimal,
	`accepted_bid`	integer NOT NULL,
	`is_done_client`	bool NOT NULL,
	`freelancer_id_id`	integer,
	`user_id_id`	integer,
	`is_done_freelancer`	bool NOT NULL,
	FOREIGN KEY(`user_id_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`freelancer_id_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `acceptedProject_acceptedproject` VALUES (1,'Dummy project','<p>asdhflaskjdf; as;djf;asldkfm asdknf;asdfn	</p>','2019-01-02 16:59:50.431134','2019-01-02 16:59:50.431173',2345,'2019-01-19 23:59:00','',NULL,NULL,6,0,10,10,0);
INSERT INTO `acceptedProject_acceptedproject` VALUES (2,'Website for my coffee shop','<h1>I urgently need a simple design and application for my shop''s website. Everything related to logic has done already by another developer from this site. But he said that was his expertise and that he didn''t agreed upon visual stuff of the site. SO PLSSS HELP MEEE!!</h1>','2019-01-02 18:03:42.786948','2019-01-02 18:03:42.786983',900,'2019-01-04 23:59:00','',NULL,NULL,7,0,9,8,0);
INSERT INTO `acceptedProject_acceptedproject` VALUES (3,'Create excel spreadsheet with formula','I require a simple spreadsheet created with only a few values, however, one which is tricky. I have attached a rough draft of the spreadsheet which indicates in the comments what is to occur. Please note, I require the spreadsheet to look much more professional then the one attached.

Please do not provide a quote until you have read and understood the requirements as per attached spreadsheet. Also, please advise which of the 2 formulas you are able to create and how long it will take.','2019-01-02 18:18:10.617374','2019-01-02 18:18:10.617412',78,'2019-10-22 12:00:00','',36,42,2,0,1,2,0);
CREATE TABLE IF NOT EXISTS `acceptedProject_acceptedmilestone` (
	`id`	integer NOT NULL PRIMARY KEY AUTOINCREMENT,
	`description`	text NOT NULL,
	`amount`	integer NOT NULL,
	`created_at`	datetime NOT NULL,
	`updated_at`	datetime NOT NULL,
	`deadline`	datetime NOT NULL,
	`file`	varchar ( 100 ) NOT NULL,
	`is_done_client`	bool NOT NULL,
	`acceptedproject_id_id`	integer NOT NULL,
	`user_id_id`	integer NOT NULL,
	`is_done_freelancer`	bool NOT NULL,
	FOREIGN KEY(`acceptedproject_id_id`) REFERENCES `acceptedProject_acceptedproject`(`id`) DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(`user_id_id`) REFERENCES `user_user`(`id`) DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO `acceptedProject_acceptedmilestone` VALUES (1,'sdjg''lskdmf sdflkgmsd;/lfg',234,'2019-01-02 16:59:50.437591','2019-01-02 17:00:08.236174','2019-01-11 22:22:00','',1,1,10,1);
INSERT INTO `acceptedProject_acceptedmilestone` VALUES (2,'sdvalsdkfa;/lskfasdmf',571,'2019-01-02 16:59:50.442582','2019-01-02 17:00:19.253337','2019-01-16 00:00:00','',1,1,10,1);
INSERT INTO `acceptedProject_acceptedmilestone` VALUES (3,'Working UI without much design.',250,'2019-01-02 18:03:42.793953','2019-01-02 18:07:21.393782','2019-01-04 00:00:00','files/dog_qLb2zXO.jpeg',1,2,9,1);
INSERT INTO `acceptedProject_acceptedmilestone` VALUES (4,'Design improved and some thought put on the UX.',500,'2019-01-02 18:03:42.804723','2019-01-02 18:07:39.556367','2019-01-06 00:00:00','',1,2,9,1);
INSERT INTO `acceptedProject_acceptedmilestone` VALUES (5,'Complete project without the hard formula',40,'2019-01-02 18:18:10.623949','2019-01-02 18:18:10.623981','2019-01-19 06:15:00','',0,3,1,0);
CREATE UNIQUE INDEX IF NOT EXISTS `user_user_user_permissions_user_id_permission_id_64f4d5b8_uniq` ON `user_user_user_permissions` (
	`user_id`,
	`permission_id`
);
CREATE INDEX IF NOT EXISTS `user_user_user_permissions_user_id_31782f58` ON `user_user_user_permissions` (
	`user_id`
);
CREATE INDEX IF NOT EXISTS `user_user_user_permissions_permission_id_ce49d4de` ON `user_user_user_permissions` (
	`permission_id`
);
CREATE UNIQUE INDEX IF NOT EXISTS `user_user_groups_user_id_group_id_bb60391f_uniq` ON `user_user_groups` (
	`user_id`,
	`group_id`
);
CREATE INDEX IF NOT EXISTS `user_user_groups_user_id_13f9a20d` ON `user_user_groups` (
	`user_id`
);
CREATE INDEX IF NOT EXISTS `user_user_groups_group_id_c57f13c0` ON `user_user_groups` (
	`group_id`
);
CREATE INDEX IF NOT EXISTS `user_freelancerprofile_tags_tag_id_f640f079` ON `user_freelancerprofile_tags` (
	`tag_id`
);
CREATE UNIQUE INDEX IF NOT EXISTS `user_freelancerprofile_tags_freelancerprofile_id_tag_id_bd751ec5_uniq` ON `user_freelancerprofile_tags` (
	`freelancerprofile_id`,
	`tag_id`
);
CREATE INDEX IF NOT EXISTS `user_freelancerprofile_tags_freelancerprofile_id_42af44e0` ON `user_freelancerprofile_tags` (
	`freelancerprofile_id`
);
CREATE INDEX IF NOT EXISTS `user_clientprofile_tags_tag_id_271bb019` ON `user_clientprofile_tags` (
	`tag_id`
);
CREATE UNIQUE INDEX IF NOT EXISTS `user_clientprofile_tags_clientprofile_id_tag_id_1d361183_uniq` ON `user_clientprofile_tags` (
	`clientprofile_id`,
	`tag_id`
);
CREATE INDEX IF NOT EXISTS `user_clientprofile_tags_clientprofile_id_8a45fb74` ON `user_clientprofile_tags` (
	`clientprofile_id`
);
CREATE INDEX IF NOT EXISTS `upload_uploadimage_user_id_871440ed` ON `upload_uploadimage` (
	`user_id`
);
CREATE INDEX IF NOT EXISTS `project_project_user_id_id_900c43f1` ON `project_project` (
	`user_id_id`
);
CREATE INDEX IF NOT EXISTS `project_project_tags_tag_id_3537f8d4` ON `project_project_tags` (
	`tag_id`
);
CREATE UNIQUE INDEX IF NOT EXISTS `project_project_tags_project_id_tag_id_be5d2870_uniq` ON `project_project_tags` (
	`project_id`,
	`tag_id`
);
CREATE INDEX IF NOT EXISTS `project_project_tags_project_id_968bd545` ON `project_project_tags` (
	`project_id`
);
CREATE INDEX IF NOT EXISTS `project_project_category_id_593c1763` ON `project_project` (
	`category_id`
);
CREATE INDEX IF NOT EXISTS `project_milestone_user_id_id_933b4a08` ON `project_milestone` (
	`user_id_id`
);
CREATE INDEX IF NOT EXISTS `project_milestone_bid_id_id_6db1c2bc` ON `project_milestone` (
	`bid_id_id`
);
CREATE INDEX IF NOT EXISTS `project_bid_user_id_id_4d42c353` ON `project_bid` (
	`user_id_id`
);
CREATE INDEX IF NOT EXISTS `project_bid_project_id_id_b0ab22b6` ON `project_bid` (
	`project_id_id`
);
CREATE INDEX IF NOT EXISTS `payment_wallet_user_id_id_41fae361` ON `payment_wallet` (
	`user_id_id`
);
CREATE INDEX IF NOT EXISTS `payment_payment_acceptedproject_id_id_a8d4949d` ON `payment_payment` (
	`acceptedproject_id_id`
);
CREATE INDEX IF NOT EXISTS `django_session_expire_date_a5c62663` ON `django_session` (
	`expire_date`
);
CREATE UNIQUE INDEX IF NOT EXISTS `django_content_type_app_label_model_76bd3d3b_uniq` ON `django_content_type` (
	`app_label`,
	`model`
);
CREATE INDEX IF NOT EXISTS `django_admin_log_user_id_c564eba6` ON `django_admin_log` (
	`user_id`
);
CREATE INDEX IF NOT EXISTS `django_admin_log_content_type_id_c4bce8eb` ON `django_admin_log` (
	`content_type_id`
);
CREATE INDEX IF NOT EXISTS `comment_freelancercomment_user_id_id_fe1aa73c` ON `comment_freelancercomment` (
	`user_id_id`
);
CREATE INDEX IF NOT EXISTS `comment_freelancercomment_profile_id_id_829c6b2b` ON `comment_freelancercomment` (
	`profile_id_id`
);
CREATE INDEX IF NOT EXISTS `comment_clientcomment_user_id_id_29261836` ON `comment_clientcomment` (
	`user_id_id`
);
CREATE INDEX IF NOT EXISTS `comment_clientcomment_profile_id_id_05875213` ON `comment_clientcomment` (
	`profile_id_id`
);
CREATE UNIQUE INDEX IF NOT EXISTS `auth_permission_content_type_id_codename_01ab375a_uniq` ON `auth_permission` (
	`content_type_id`,
	`codename`
);
CREATE INDEX IF NOT EXISTS `auth_permission_content_type_id_2f476e4b` ON `auth_permission` (
	`content_type_id`
);
CREATE INDEX IF NOT EXISTS `auth_group_permissions_permission_id_84c5c92e` ON `auth_group_permissions` (
	`permission_id`
);
CREATE UNIQUE INDEX IF NOT EXISTS `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` ON `auth_group_permissions` (
	`group_id`,
	`permission_id`
);
CREATE INDEX IF NOT EXISTS `auth_group_permissions_group_id_b120cbf9` ON `auth_group_permissions` (
	`group_id`
);
CREATE INDEX IF NOT EXISTS `annotation_textannotation_user_id_f8a352b7` ON `annotation_textannotation` (
	`user_id`
);
CREATE INDEX IF NOT EXISTS `annotation_textannotation_target_id_c17e8da8` ON `annotation_textannotation` (
	`target_id`
);
CREATE INDEX IF NOT EXISTS `annotation_textannotation_body_id_14f7e2c1` ON `annotation_textannotation` (
	`body_id`
);
CREATE INDEX IF NOT EXISTS `annotation_target_selector_id_76047888` ON `annotation_target` (
	`selector_id`
);
CREATE INDEX IF NOT EXISTS `annotation_startendselector_refinedBy_id_d69ec34f` ON `annotation_startendselector` (
	`refinedBy_id`
);
CREATE INDEX IF NOT EXISTS `annotation_selector_startSelector_id_2c22ec3f` ON `annotation_selector` (
	`startSelector_id`
);
CREATE INDEX IF NOT EXISTS `annotation_selector_endSelector_id_d4b1f3cf` ON `annotation_selector` (
	`endSelector_id`
);
CREATE INDEX IF NOT EXISTS `annotation_imagetarget_selector_id_65a23d8a` ON `annotation_imagetarget` (
	`selector_id`
);
CREATE INDEX IF NOT EXISTS `annotation_imageannotation_user_id_b5e18194` ON `annotation_imageannotation` (
	`user_id`
);
CREATE INDEX IF NOT EXISTS `annotation_imageannotation_target_id_2aee1d97` ON `annotation_imageannotation` (
	`target_id`
);
CREATE INDEX IF NOT EXISTS `annotation_imageannotation_body_id_4ca0604c` ON `annotation_imageannotation` (
	`body_id`
);
CREATE INDEX IF NOT EXISTS `acceptedProject_acceptedproject_user_id_id_aa24d1ae` ON `acceptedProject_acceptedproject` (
	`user_id_id`
);
CREATE INDEX IF NOT EXISTS `acceptedProject_acceptedproject_freelancer_id_id_e6872272` ON `acceptedProject_acceptedproject` (
	`freelancer_id_id`
);
CREATE INDEX IF NOT EXISTS `acceptedProject_acceptedmilestone_user_id_id_d86e889f` ON `acceptedProject_acceptedmilestone` (
	`user_id_id`
);
CREATE INDEX IF NOT EXISTS `acceptedProject_acceptedmilestone_acceptedproject_id_id_c58652c2` ON `acceptedProject_acceptedmilestone` (
	`acceptedproject_id_id`
);
COMMIT;
